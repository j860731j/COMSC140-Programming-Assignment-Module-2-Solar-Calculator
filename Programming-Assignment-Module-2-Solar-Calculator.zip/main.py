def solar_payback_period():
    count=0
    fname="solar.txt"
    myfile=open(fname,"w")
    while True:
        cost=float(input("Total initial cost of the system (in USD, -1 to exit):"))
        if (cost==-1):
            print("Wrote a total of",count,"calculation(s) to solar.txt.")
            print("Exiting...")
            break
        bill=float(input("Expected yearly energy bill (in USD):"))
        tax=float(input("Tax credit percentage to apply (as a decimal number):"))
        count+=1
        payback=cost*(1-tax)/bill
        print("The expected payback period of this system is:","{:.2f}".format(payback),"years.")
        myfile.write("{:.2f}".format(payback)+"\n")
    myfile.close()
    return payback
if __name__=="__main__":
    solar_payback_period()